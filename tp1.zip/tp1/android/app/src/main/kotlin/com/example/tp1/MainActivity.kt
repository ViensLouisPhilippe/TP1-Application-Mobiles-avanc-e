package com.example.tp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
